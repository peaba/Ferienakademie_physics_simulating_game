#ifndef TARGET_FPS_H
#define TARGET_FPS_H

/* This generated file contains includes for project dependencies */
#include "target_fps/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

