#ifndef SYSTEM_CTX_H
#define SYSTEM_CTX_H

/* This generated file contains includes for project dependencies */
#include "system_ctx/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

