#ifndef UNION_H
#define UNION_H

/* This generated file contains includes for project dependencies */
#include "union/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

