#ifndef SER_OPAQUE_VECTOR_H
#define SER_OPAQUE_VECTOR_H

/* This generated file contains includes for project dependencies */
#include "ser_opaque_vector/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

