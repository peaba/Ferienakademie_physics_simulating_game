#ifndef NESTED_STRUCT_H
#define NESTED_STRUCT_H

/* This generated file contains includes for project dependencies */
#include "nested_struct/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

