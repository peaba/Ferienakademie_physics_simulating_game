#ifndef BASICS_ENUM_H
#define BASICS_ENUM_H

/* This generated file contains includes for project dependencies */
#include "basics_enum/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

