#ifndef HELLO_WORLD_H
#define HELLO_WORLD_H

/* This generated file contains includes for project dependencies */
#include "hello_world/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

