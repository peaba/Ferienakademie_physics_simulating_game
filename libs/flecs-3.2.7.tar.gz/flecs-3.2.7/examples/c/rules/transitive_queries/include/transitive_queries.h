#ifndef TRANSITIVE_QUERIES_H
#define TRANSITIVE_QUERIES_H

/* This generated file contains includes for project dependencies */
#include "transitive_queries/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

