#ifndef FACTS_H
#define FACTS_H

/* This generated file contains includes for project dependencies */
#include "facts/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

