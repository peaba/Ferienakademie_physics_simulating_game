#ifndef GROUP_BY_CALLBACKS_H
#define GROUP_BY_CALLBACKS_H

/* This generated file contains includes for project dependencies */
#include "group_by_callbacks/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

