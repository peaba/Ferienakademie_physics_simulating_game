#ifndef GROUP_ITER_H
#define GROUP_ITER_H

/* This generated file contains includes for project dependencies */
#include "group_iter/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

