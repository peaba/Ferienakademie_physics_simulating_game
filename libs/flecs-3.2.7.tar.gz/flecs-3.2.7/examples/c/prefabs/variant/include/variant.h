#ifndef VARIANT_H
#define VARIANT_H

/* This generated file contains includes for project dependencies */
#include "variant/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

