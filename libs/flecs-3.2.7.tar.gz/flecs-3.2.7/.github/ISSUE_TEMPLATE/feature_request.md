---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Describe the problem you are trying to solve.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]. Refrain from proposing a solution here.

**Describe the solution you'd like**
A clear and concise description of what you would like to happen.
